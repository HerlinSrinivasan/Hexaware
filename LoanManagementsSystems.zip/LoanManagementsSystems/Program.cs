﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace LoanManagementsSystems
{
    //Task 1: Define Customer Class with attribues

    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public int CreditScore { get; set; }


        // Task 4: Constructors, getters, setters, print method
        public Customer() { }

        public Customer(int customerId, string name, string emailAddress, string phoneNumber, string address, int creditScore)
        {
            CustomerId = customerId;
            Name = name;
            EmailAddress = emailAddress;
            PhoneNumber = phoneNumber;
            Address = address;
            CreditScore = creditScore;
        }
        public void PrintCustomerDetails()
        {
            Console.WriteLine($"CustomerId: {CustomerId}, Name: {Name}, Email: {EmailAddress}, Phone: {PhoneNumber}, Address: {Address}, Credit Score: {CreditScore}");
        }
    }
    // Task 2: Define base Loan class

    public class Loan
    {
        public int LoanId { get; set; }
        public Customer Customer { get; set; }
        public double PrincipalAmount { get; set; }
        public double InterestRate { get; set; }
        public int LoanTerm { get; set; } // in months
        public string LoanType { get; set; } // e.g., Carloan.homeloan
        public string LoanStatus { get; set; } // e.g., Approved, Pending, Rejected

        //Task 4: Constructors, getters, setters, print method
        public Loan() { }
        public Loan(int loanId, Customer customer, double principalAmount, double interestRate, int loanTerm, string loanType, string loanStatus)
        {
            LoanId = loanId;
            Customer = customer;
            PrincipalAmount = principalAmount;
            InterestRate = interestRate;
            LoanTerm = loanTerm;
            LoanType = loanType;
            LoanStatus = loanStatus;
        }
        public virtual void PrintLoanDetails() //this means the method can be overridden in derived classes
        {
            Console.WriteLine($"LoanId: {LoanId}, Customer: {Customer.Name}, Principal Amount: {PrincipalAmount}, Interest Rate: {InterestRate}, Loan Term: {LoanTerm} months, Loan Type: {LoanType}, Loan Status: {LoanStatus}");
        }
    }

    // Task 3a: HomeLoan subclass
    public class HomeLoan : Loan
    {
        public string PropertyAddress { get; set; }
        public double PropertyValue { get; set; }


        public HomeLoan() { }

        public HomeLoan(int loanId, Customer customer, double principalAmount, double interestRate, int loanTerm, string loanType, string loanStatus, string propertyAddress, double propertyValue)
            : base(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus)
        {
            PropertyAddress = propertyAddress;
            PropertyValue = propertyValue;
        }

        public override void PrintLoanDetails()
        {
            base.PrintLoanDetails();
            Console.WriteLine($"Property Address: {PropertyAddress}, Property Value: {PropertyValue}");
        }
    }
    // Task 3b: CarLoan subclass

    public class CarLoan : Loan
    {
        public string CarModel { get; set; }
        public int CarValue { get; set; }

        public CarLoan() { }
        public CarLoan(int loanId, Customer customer, double principalAmount, double interestRate, int loanTerm, string loanType, string loanStatus, string carModel, int carValue)
            : base(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus)
        {
            CarModel = carModel;
            CarValue = carValue;
        }

        public override void PrintLoanDetails()
        {
            base.PrintLoanDetails();
            Console.WriteLine($"Car Model: {CarModel}, Car Value: {CarValue}");
        }
    }

    // Task 5 : Define ILoanRepository interface/abstract class with following methods to interact with database.

    public interface ILoanRepository
    {
        void ApplyLoan();
        double CalculateInterest(int loanId); ////existing loan
        double CalculateInterest(double principal, double rate, int term);
        void LoanStatus(int loanId);
        double CalculateEMI(int loanId);//existing loan
        void LoanRepayment(int loanId, double amount);
        List<Loan> GetAllLoan();
        Loan GetLoanById(int loanId);
    }

    // Task 6: Implement ILoanRepository

    // Final Updated LoanRepositoryImpl to fully work with DB for all choices using System; using System.Collections.Generic; using System.Data; using System.Data.SqlClient;

   
        public class LoanRepositoryImpl : ILoanRepository
    {
        private Customer FindCustomerFromDBById(int customerId)
        {
            using (SqlConnection conn = DBUtil.GetDBConn())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Customer WHERE CustomerId = @CustomerId", conn);
                cmd.Parameters.AddWithValue("@CustomerId", customerId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Customer
                        {
                            CustomerId = Convert.ToInt32(reader["CustomerId"]),
                            Name = reader["Name"].ToString(),
                            EmailAddress = reader["Email"].ToString(),
                            PhoneNumber = reader["PhoneNumber"].ToString(),
                            Address = reader["Address"].ToString(),
                            CreditScore = Convert.ToInt32(reader["CreditScore"])
                        };
                    }
                    else
                    {
                        throw new Exception("InvalidCustomerException: Customer not found.");
                    }
                }
            }
        }
        public void ApplyLoan()
            {
                Console.WriteLine("Enter Customer Details:");

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Email: ");
                string email = Console.ReadLine();

                Console.Write("Phone Number: ");
                string phone = Console.ReadLine();

                Console.Write("Address: ");
                string address = Console.ReadLine();

                Console.Write("Credit Score (300 - 900): ");
                int creditScore = int.Parse(Console.ReadLine());

                int customerId;
                using (SqlConnection conn = DBUtil.GetDBConn())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO Customer (Name, Email, PhoneNumber, Address, CreditScore) OUTPUT INSERTED.CustomerId VALUES (@Name, @Email, @Phone, @Address, @CreditScore)", conn);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Phone", phone);
                    cmd.Parameters.AddWithValue("@Address", address);
                    cmd.Parameters.AddWithValue("@CreditScore", creditScore);

                    customerId = Convert.ToInt32(cmd.ExecuteScalar());
                }

                Console.WriteLine("\nSelect Loan Type:");
                Console.WriteLine("1. Home Loan");
                Console.WriteLine("2. Car Loan");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                Loan loan = null;

                if (choice == 1)
                {
                    Console.Write("Enter Property Address: ");
                    string propertyAddress = Console.ReadLine();

                    Console.Write("Enter Property Value: ");
                    long propertyValue = long.Parse(Console.ReadLine());

                    double principalAmount = propertyValue * 0.8;
                    double interestRate = 7.5;
                    int loanTerm = 240;

                    loan = new HomeLoan
                    {
                        Customer = new Customer { CustomerId = customerId },
                        PrincipalAmount = principalAmount,
                        InterestRate = interestRate,
                        LoanTerm = loanTerm,
                        LoanType = "HomeLoan",
                        LoanStatus = "Pending",
                        PropertyAddress = propertyAddress,
                        PropertyValue = propertyValue
                    };
                }
                else if (choice == 2)
                {
                    Console.Write("Enter Car Model: ");
                    string carModel = Console.ReadLine();

                    Console.Write("Enter Car Value: ");
                    int carValue = int.Parse(Console.ReadLine());

                    double principalAmount = carValue * 0.85;
                    double interestRate = 9.0;
                    int loanTerm = 60;

                    loan = new CarLoan
                    {
                        Customer = new Customer { CustomerId = customerId },
                        PrincipalAmount = principalAmount,
                        InterestRate = interestRate,
                        LoanTerm = loanTerm,
                        LoanType = "CarLoan",
                        LoanStatus = "Pending",
                        CarModel = carModel,
                        CarValue = carValue
                    };
                }
                else
                {
                    Console.WriteLine("Invalid choice. Loan application cancelled.");
                    return;
                }

                using (SqlConnection conn = DBUtil.GetDBConn())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO Loan (CustomerId, PrincipalAmount, InterestRate, LoanTerm, LoanType, LoanStatus) OUTPUT INSERTED.LoanId VALUES (@CustomerId, @PrincipalAmount, @InterestRate, @LoanTerm, @LoanType, @LoanStatus)", conn);
                    cmd.Parameters.AddWithValue("@CustomerId", customerId);
                    cmd.Parameters.AddWithValue("@PrincipalAmount", loan.PrincipalAmount);
                    cmd.Parameters.AddWithValue("@InterestRate", loan.InterestRate);
                    cmd.Parameters.AddWithValue("@LoanTerm", loan.LoanTerm);
                    cmd.Parameters.AddWithValue("@LoanType", loan.LoanType);
                    cmd.Parameters.AddWithValue("@LoanStatus", loan.LoanStatus);

                    loan.LoanId = Convert.ToInt32(cmd.ExecuteScalar());
                }

                Console.WriteLine("\nLoan Application Submitted Successfully.");
                loan.PrintLoanDetails();
            }

            public double CalculateInterest(int loanId)
            {
                Loan loan = GetLoanById(loanId);
                return (loan.PrincipalAmount * loan.InterestRate * loan.LoanTerm) / 12;
            }

            public double CalculateInterest(double principal, double rate, int term)
            {
                return (principal * rate * term) / 12;
            }

            public void LoanStatus(int loanId)
            {
                Loan loan = GetLoanById(loanId);
                Customer cust = GetCustomerById(loan.Customer.CustomerId);
                loan.LoanStatus = (cust.CreditScore > 650) ? "Approved" : "Rejected";

                using (SqlConnection conn = DBUtil.GetDBConn())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Loan SET LoanStatus = @Status WHERE LoanId = @LoanId", conn);
                    cmd.Parameters.AddWithValue("@Status", loan.LoanStatus);
                    cmd.Parameters.AddWithValue("@LoanId", loan.LoanId);
                    cmd.ExecuteNonQuery();
                }
                Console.WriteLine($"Loan {loanId} status updated to {loan.LoanStatus}.");
            }

            public double CalculateEMI(int loanId)
            {
                Loan loan = GetLoanById(loanId);
                double monthlyRate = loan.InterestRate / 12 / 100;
                return (loan.PrincipalAmount * monthlyRate * Math.Pow(1 + monthlyRate, loan.LoanTerm)) / (Math.Pow(1 + monthlyRate, loan.LoanTerm) - 1);
            }

            public void LoanRepayment(int loanId, double amount)
            {
                double emi = CalculateEMI(loanId);
                if (amount < emi)
                    Console.WriteLine("Payment rejected. Amount less than EMI.");
                else
                    Console.WriteLine($"Payment accepted. Number of EMIs paid: {(int)(amount / emi)}");
            }

        public List<Loan> GetAllLoan()
        {
            List<Loan> loanList = new List<Loan>();

            using (SqlConnection conn = DBUtil.GetDBConn())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Loan", conn);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int loanId = Convert.ToInt32(reader["LoanId"]);
                        int customerId = Convert.ToInt32(reader["CustomerId"]);
                        double principalAmount = Convert.ToDouble(reader["PrincipalAmount"]);
                        double interestRate = Convert.ToDouble(reader["InterestRate"]);
                        int loanTerm = Convert.ToInt32(reader["LoanTerm"]);
                        string loanType = reader["LoanType"].ToString();
                        string loanStatus = reader["LoanStatus"].ToString();

                        Customer customer = FindCustomerFromDBById(customerId);

                        Loan loan;

                        if (loanType == "HomeLoan")
                        {
                            // You can extend this to fetch additional home loan properties if required
                            loan = new HomeLoan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }
                        else if (loanType == "CarLoan")
                        {
                            // You can extend this to fetch additional car loan properties if required
                            loan = new CarLoan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }
                        else
                        {
                            loan = new Loan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }

                        loanList.Add(loan);
                    }
                }
            }

            // Print Loan Details
            foreach (Loan loan in loanList)
            {
                Console.WriteLine($"\nLoan taken by {loan.Customer.Name}:");
                loan.PrintLoanDetails();
            }

            return loanList;
        }
        public Loan GetLoanById(int loanId)
        {
            using (SqlConnection conn = DBUtil.GetDBConn())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Loan WHERE LoanId = @LoanId", conn);
                cmd.Parameters.AddWithValue("@LoanId", loanId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int customerId = Convert.ToInt32(reader["CustomerId"]);
                        double principalAmount = Convert.ToDouble(reader["PrincipalAmount"]);
                        double interestRate = Convert.ToDouble(reader["InterestRate"]);
                        int loanTerm = Convert.ToInt32(reader["LoanTerm"]);
                        string loanType = reader["LoanType"].ToString();
                        string loanStatus = reader["LoanStatus"].ToString();

                        Customer customer = FindCustomerFromDBById(customerId);

                        Loan loan;

                        if (loanType == "HomeLoan")
                        {
                            loan = new HomeLoan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }
                        else if (loanType == "CarLoan")
                        {
                            loan = new CarLoan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }
                        else
                        {
                            loan = new Loan
                            {
                                LoanId = loanId,
                                Customer = customer,
                                PrincipalAmount = principalAmount,
                                InterestRate = interestRate,
                                LoanTerm = loanTerm,
                                LoanType = loanType,
                                LoanStatus = loanStatus
                            };
                        }

                        // Print Loan Details
                        Console.WriteLine($"\nLoan Details for Loan ID: {loanId}");
                        loan.PrintLoanDetails();

                        return loan;
                    }
                    else
                    {
                        throw new Exception("InvalidLoanException: Loan not found.");
                    }
                }
            }
        }

        private Customer GetCustomerById(int customerId)
            {
                using (SqlConnection conn = DBUtil.GetDBConn())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Customer WHERE CustomerId = @Id", conn);
                    cmd.Parameters.AddWithValue("@Id", customerId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        return new Customer
                        {
                            CustomerId = Convert.ToInt32(reader["CustomerId"]),
                            Name = reader["Name"].ToString(),
                            EmailAddress = reader["Email"].ToString(),
                            PhoneNumber = reader["PhoneNumber"].ToString(),
                            Address = reader["Address"].ToString(),
                            CreditScore = Convert.ToInt32(reader["CreditScore"])
                        };
                    }
                    throw new Exception("Customer not found.");
                }
            }
        }

    




    //Task 7 : Create DBUtil class and add the following method.
    public class DBUtil
    {
        public static SqlConnection GetDBConn()
        {
            string connectionString = "Server=DESKTOP-BCL1U6L;Database=LoanManagementSystemDB;Trusted_Connection=True;";
            return new SqlConnection(connectionString);
        }
    }

    // Task 8: Main class to simulate the system
    public class LoanManagement
    {
        public static void Main(string[] args)
        {
            LoanRepositoryImpl loanRepo = new LoanRepositoryImpl();

            while (true)
            {
                Console.WriteLine("\n===== Loan Management System =====");
                Console.WriteLine("1. Apply Loan");
                Console.WriteLine("2. Calculate Interest");
                Console.WriteLine("3. Check Loan Status");
                Console.WriteLine("4. Calculate EMI");
                Console.WriteLine("5. Make Loan Repayment");
                Console.WriteLine("6. Get All Loans");
                Console.WriteLine("7. Get Loan By ID");
                Console.WriteLine("8. Exit");
                Console.Write("Enter your choice: ");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        loanRepo.ApplyLoan();
                        break;

                    case 2:
                        Console.Write("Enter Loan ID: ");
                        int loanId = int.Parse(Console.ReadLine());
                        double interest = loanRepo.CalculateInterest(loanId);
                        Console.WriteLine($"Calculated Interest: {interest}");
                        break;

                    case 3:
                        Console.Write("Enter Loan ID: ");
                        loanId = int.Parse(Console.ReadLine());
                        loanRepo.LoanStatus(loanId);
                        break;

                    case 4:
                        Console.Write("Enter Loan ID: ");
                        loanId = int.Parse(Console.ReadLine());
                        double emi = loanRepo.CalculateEMI(loanId);
                        Console.WriteLine($"EMI Amount: {emi}");
                        break;

                    case 5:
                        Console.Write("Enter Loan ID: ");
                        loanId = int.Parse(Console.ReadLine());
                        Console.Write("Enter Repayment Amount: ");
                        double amount = double.Parse(Console.ReadLine());
                        loanRepo.LoanRepayment(loanId, amount);
                        break;

                    case 6:
                        List<Loan> loans = loanRepo.GetAllLoan();

                        if (loans.Count == 0)
                        {
                            Console.WriteLine("No loans found.");
                        }
                        else
                        {
                            foreach (Loan loan in loans)
                            {
                                loan.PrintLoanDetails();
                                Console.WriteLine("-----------------------------------");
                            }
                        }
                        break;

                    case 7:
                        Console.Write("Enter Loan ID: ");
                        loanId = int.Parse(Console.ReadLine());
                        loanRepo.GetLoanById(loanId);
                        break;

                    case 8:
                        Console.WriteLine("Exiting...");
                        return;

                    default:
                        Console.WriteLine("Invalid choice, try again.");
                        break;
                }
            }

        }

    }
}


