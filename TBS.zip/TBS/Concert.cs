﻿////TASK 5
//using System;


//namespace TBS
//{
//    public class Concert : Event
//    {

//        public string artist;
//        public string type;


//        //default constructor

//        public Concert() : base()
//        {
//            artist = "";
//            type = "";

//        }

//        //overload constructor

//        public Concert(string event_name, DateTime event_date, DateTime event_time, string venue_name, int total_seats, decimal ticket_price, EventType event_type, string genre, string artist, string type) : base(event_name, event_date, event_time, venue_name, total_seats, ticket_price, event_type)
//        {
//            this.artist = artist;
//            this.type = type;
//        }

//        public new void DisplayEventDetails()
//        {
//            base.DisplayEventDetails();
            
//            Console.WriteLine("Artist" + artist);
//            Console.WriteLine("Concert Type" + type);
//        }

//    }
//}
