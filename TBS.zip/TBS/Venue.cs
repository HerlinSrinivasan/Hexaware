﻿////TASK 4


//using System;


//namespace TBS
//{
//    public class Venue
//    {
//        private string venue_name;
//        private string address;

//        //default constructor
//        public Venue()
//        {
//            venue_name = "";
//            address = "";

//        }

//        //overload constructor
//        public Venue(string venue_name, string address)
//        {
//            this.venue_name = venue_name;
//            this.address = address;
//        }

//        //setter and getter method

//        public void SetVenueName(string venue_name)
//        {
//            this.venue_name = venue_name;
//        }
//        public string GetVenueName()
//        {
//            return venue_name;
//        }

//        public void SetAddress(string address)
//        {
//            this.address = address;
//        }
//        public string GetAddress()
//        {
//            return address;
//        }

//        //display venue details
//        public void DisplayVenueDetails()
//        {
//            Console.WriteLine("\n ---------Venue Details-----");
//            Console.WriteLine("Name :" + venue_name);
//            Console.WriteLine("Address :" + address);
//            Console.WriteLine("\n ----------------");
//        }
//    }
//}
