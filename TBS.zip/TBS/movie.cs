﻿////TASK 5
//using System;


//namespace TBS
//{
//    public class Movie : Event
//    {
//        public string genre;
//        public string actorName;
//        public string actressName;


//        //default constructor

//        public Movie() : base()
//        {
//            genre = "";
//            actorName = "";
//            actressName = "";

//        }

//        //overload constructor

//        public Movie(string event_name, DateTime event_date, DateTime event_time, string venue_name, int total_seats, decimal ticket_price, EventType event_type,string genre,string actorName,string actressName): base(event_name,event_date,event_time,venue_name,total_seats,ticket_price,event_type)
//        {
//            this.genre = genre;
//            this.actorName = actorName;
//            this.actressName = actressName;
//        }

//        public new void DisplayEventDetails()
//        {
//            base.DisplayEventDetails();
//            Console.WriteLine("Genre " + genre);
//            Console.WriteLine("Actor Name " + actorName);
//            Console.WriteLine("Actress Name" + actressName);
//        }

//    }
//}

