﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace TBS
//{
//    internal class ticket_booking_system
//    {
//        static void Main(string[] args)
//        {

/*Task 1: Conditional Statements
In a BookingSystem, you have been given the task is to create a program to book tickets. if available
t
ickets more than noOfTicket to book then display the remaining tickets or ticket unavailable:
Tasks:
  1.Write a program that takes the availableTicket and noOfBookingTicket as input.
2.Use conditional statements(if-else) to determine if the ticket is available or not.
3.Display an appropriate message based on ticket availability.
Task 2: Nested Conditional Statements
Create a program that simulates a Ticket booking and calculating cost of tickets. Display tickets options
such as "Silver", "Gold", "Dimond".Based on ticket category fix the base ticket price and get the user input
for ticket type and no of tickets need and calculate the total cost of tickets booked.
Task 3: Looping
From the above task book the tickets for repeatedly until user type "Exit" */

//    while (true)
//    {
//        Console.WriteLine("Enter the number of tickets to book:");
//        int noOfBookingTickets = Convert.ToInt32(Console.ReadLine());
//        if (noOfBookingTickets <= myEvent.GetAvailableSeats())
//        {
//            Console.WriteLine("Ticket Available for booking.");
//        }
//        else
//        {
//            Console.WriteLine("Sorry, not enough tickets available for booking. Available Tickets : " + myEvent.GetAvailableSeats());
//            break;
//        }


//        Console.OutputEncoding = System.Text.Encoding.UTF8;

//        Console.WriteLine("Ticket Options");
//        Console.WriteLine("1. Silver - ₹800");
//        Console.WriteLine("2. Gold - ₹1500");
//        Console.WriteLine("3. Diamond - ₹2500");

//        Console.WriteLine("Enter your choice(silver/gold/diamond)");
//        string ticketType = Console.ReadLine().ToLower().Trim();
//        decimal ticketPrice = 0;
//        if (ticketType == "silver")
//        {
//            ticketPrice = 800;
//        }
//        else if (ticketType == "gold")
//        {
//            ticketPrice = 1500;
//        }
//        else if (ticketType == "diamond")
//        {
//            ticketPrice = 2500;
//        }
//        else
//        {
//            Console.WriteLine("Invalid ticket type selected.");
//            continue;
//        }
//        myEvent.BookTickets(noOfBookingTickets);


//        decimal totalCost = noOfBookingTickets * ticketPrice;
//        Console.WriteLine("Total cost for Booking" + " " + noOfBookingTickets + " " + ticketType + "tickets : ₹" + totalCost);

//        Console.WriteLine("Do you want to book more tickets? (yes/EXIT)");
//        string response = Console.ReadLine().ToLower().Trim();
//        if (response == "exit")
//        {
//            Console.WriteLine("Thank you for using the ticket booking system. Goodbye!");
//            break;
//        }
//    }
//}
//=======================================================================================================================================================
//TASK 4 is class and object, so i have created seperate class for event,venue,customer and booking
//=========================================================================================================================================
/* TASK 5
 * 1. Inheritance - I have createdthe classes movie,concert,sports that inherits from Event
 * Create a class TicketBookingSystem with the following methods:  
o create_event(event_name: str, date:str, time:str, total_seats: int, ticket_price: 
float, event_type: str, venu_name:str): Create a new event with the specified details 
and event type (movie, sport or concert) and return event object.  
o display_event_details(event: Event): Accepts an event object and calls its 
display_event_details() method to display event details. 
o book_tickets(event: Event, num_tickets: int):  
1. Accepts an event object and the number of tickets to be booked. 
2. Checks if there are enough available seats for the booking. 
3. If seats are available, updates the available seats and returns the total cost 
of the booking. 
4. If seats are not available, displays a message indicating that the event is sold 
out. 
   main(): simulates the ticket booking system 
1. User can book tickets and view the event details as per their choice in menu 
(movies, sports, concerts). 
2. Display event details using the display_event_details() method without 
knowing the specific event type (demonstrate polymorphism). 
3. Make bookings using the book_tickets() and cancel tickets cancel_tickets() 
method.  */



//            TicketBookingSystem system = new TicketBookingSystem();

////pre creating one event for Movie,Sports and concert for demonstration

//Event movieEvent = system.CreateEvent("Movie Night", DateTime.Now.Date, DateTime.Now, "PVR Cinemas", 100, 250, "Movie");
//Event sportEvent = system.CreateEvent("Football Match", DateTime.Now.Date, DateTime.Now, "Stadium", 200, 500, "Sports"); Event concertEvent = system.CreateEvent("Rock Concert", DateTime.Now.Date, DateTime.Now, "Arena", 150, 800, "Concert");

//while (true)
//{
//    Console.WriteLine("\n--- Ticket Booking System ---");
//    Console.WriteLine("1. Movie");
//    Console.WriteLine("2. Sports");
//    Console.WriteLine("3. Concert");
//    Console.WriteLine("4. Exit");
//    Console.Write("Select Event Type: ");
//    string choice = Console.ReadLine();

//    Event selectedEvent = null;

//    switch (choice)
//    {
//        case "1":
//            selectedEvent = movieEvent;
//            break;
//        case "2":
//            selectedEvent = sportEvent;
//            break;
//        case "3":
//            selectedEvent = concertEvent;
//            break;
//        case "4":
//            Console.WriteLine("Exiting...");
//            return;
//        default:
//            Console.WriteLine("Invalid choice.");
//            continue;
//    }
//    while (true)
//    {
//        Console.WriteLine("\n--- Actions for Selected Event ---");
//        Console.WriteLine("1. View Event Details");
//        Console.WriteLine("2. Book Tickets");
//        Console.WriteLine("3. Cancel Tickets");
//        Console.WriteLine("4. Back to Event Selection");
//        Console.Write("Enter your choice: ");
//        string action = Console.ReadLine();

//        if (action == "1")
//        {
//            system.DisplayEventDetails(selectedEvent);  // Polymorphism in action
//        }
//        else if (action == "2")
//        {
//            Console.Write("Enter number of tickets to book: ");
//            int numTickets = int.Parse(Console.ReadLine());
//            system.BookTickets(selectedEvent, numTickets);
//        }
//        else if (action == "3")
//        {
//            Console.Write("Enter number of tickets to cancel: ");
//            int numTickets = int.Parse(Console.ReadLine());
//            system.CancelTickets(selectedEvent, numTickets);
//        }
//        else if (action == "4")
//        {
//            break; // Back to main menu
//        }
//        else
//        {
//            Console.WriteLine("Invalid choice.");
//        }
//    }
// }
//}
//}
//}
//============================================================================================================================================


// TASK 6 - Abstract Class
/* 1. Event Abstraction: 
• Create an abstract class Event that represents a generic event. It should include the 
following attributes and methods as mentioned in TASK 1: */

//using System;
//using System.Runtime.Remoting.Contexts;
//namespace TBS
//{
//    public abstract class EventBase
//    {
//        public string EventName { get; set; }
//        public DateTime EventDate { get; set; }
//        public string VenueName { get; set; }
//        public int TotalSeats { get; set; }
//        public int AvailableSeats { get; set; }
//        public decimal TicketPrice { get; set; }

//        public EventBase(string name, DateTime date, string venue, int totalSeats, decimal price)
//        {
//            EventName = name;
//            EventDate = date;
//            VenueName = venue;
//            TotalSeats = totalSeats;
//            AvailableSeats = totalSeats;
//            TicketPrice = price;

//        }
//        public abstract void DisplayEventDetails();
//    }

//    /* 2. Concrete Event Classes: 
//• Create three concrete classes that inherit from Event abstract class and override abstract 
//methods in concrete class should declare the variables as mentioned in above Task 2: 
//• Movie. 
//• Concert. 
//• Sport. */

//    // Movie class
//    public class Movies: EventBase
//    {
//        public Movies(string name, DateTime date, string venue, int totalSeats, decimal price)
//            : base(name, date, venue, totalSeats, price) { }
//        public override void DisplayEventDetails()
//        {
//            Console.WriteLine("--Movie Event---");
//            Console.WriteLine("Name : " + EventName);
//            Console.WriteLine("Date :" + EventDate);
//            Console.WriteLine("Venue :" + VenueName);
//            Console.WriteLine("Total seats : " + TotalSeats);
//            Console.WriteLine("Available seats : " + AvailableSeats);
//            Console.WriteLine("Ticket price : " + TicketPrice);
//        }
//    }
//    public class Sports: EventBase
//    {
//        public Sports(string name, DateTime date, string venue, int totalSeats, decimal price)
//            : base(name, date, venue, totalSeats, price) { }

//        public override void DisplayEventDetails()
//        {
//            Console.WriteLine("--Sport Event---");
//            Console.WriteLine("Name : " + EventName);
//            Console.WriteLine("Date :" + EventDate);
//            Console.WriteLine("Venue :" + VenueName);
//            Console.WriteLine("Total seats : " + TotalSeats);
//            Console.WriteLine("Available seats : " + AvailableSeats);
//            Console.WriteLine("Ticket price : " + TicketPrice);
//        }
//    }
//    // Concert class
//    public class Concerts: EventBase
//    {
//        public Concerts(string name, DateTime date, string venue, int totalSeats, decimal price)
//            : base(name, date, venue, totalSeats, price) { }

//        public override void DisplayEventDetails()
//        {
//            Console.WriteLine("--Concert Event---");
//            Console.WriteLine("Name : " + EventName);
//            Console.WriteLine("Date :" + EventDate);
//            Console.WriteLine("Venue :" + VenueName);
//            Console.WriteLine("Total seats : " + TotalSeats);
//            Console.WriteLine("Available seats : " + AvailableSeats);
//            Console.WriteLine("Ticket price : " + TicketPrice);
//        }
//    }

//    // Main program -- checking the above abstract class
//    //class Program
//    //{
//    //    static void Main(string[] args)
//    //    {
//    //        // Testing Movie
//    //        EventBase movie = new Movies("Avengers", DateTime.Now.Date, "PVR Cinemas", 100, 250);
//    //        movie.DisplayEventDetails();

//    //        // Testing Sport
//    //        EventBase sport = new Sports("Football Match", DateTime.Now.Date, "Stadium", 200, 500);
//    //        sport.DisplayEventDetails();

//    //        // Testing Concert
//    //        EventBase concert = new Concerts("Rock Concert", DateTime.Now.Date, "Music Arena", 150, 800);
//    //        concert.DisplayEventDetails();
//    //    }
//    //}

/* 3 & 4. Create an abstract class BookingSystem that represents the ticket booking system reate a concrete class TicketBookingSystem that inherits from BookingSystem: 
• TicketBookingSystem: Implement the abstract methods to create events, book 
tickets, and retrieve available seats. Maintain an array of events in this class. 
• Create a simple user interface in a main method that allows users to interact with the ticket 
booking system by entering commands such as "create_event", "book_tickets",
"cancel_tickets", "get_available_seats," and "exit."  */



using System;
using System.Collections.Generic;

namespace TicketBookingApp
{
    // Abstract Booking System
    public abstract class BookingSystem
    {
        public abstract MyEvent CreateEvent(string name, int totalSeats, decimal price);
        public abstract void BookTickets(string eventName, int numTickets);
        public abstract void CancelTickets(string eventName, int numTickets);
        public abstract int GetAvailableSeats(string eventName);
        public abstract void DisplayAllEvents();
    }

    // Event class
    public class MyEvent
    {
        public string EventName { get; set; }
        public int TotalSeats { get; set; }
        public int AvailableSeats { get; set; }
        public decimal TicketPrice { get; set; }

        public MyEvent(string name, int seats, decimal price)
        {
            EventName = name;
            TotalSeats = seats;
            AvailableSeats = seats;
            TicketPrice = price;
        }

        public void DisplayDetails()
        {
            Console.WriteLine($"Event: {EventName} | Total Seats: {TotalSeats} | Available: {AvailableSeats} | Price: {TicketPrice}");
        }
    }

    // Concrete Booking System
    public class TicketBookingSystem : BookingSystem
    {
        private List<MyEvent> events = new List<MyEvent>();

        public override MyEvent CreateEvent(string name, int totalSeats, decimal price)
        {
            MyEvent newEvent = new MyEvent(name, totalSeats, price);
            events.Add(newEvent);
            Console.WriteLine("Event created successfully.\n");
            return newEvent;
        }

        public override void BookTickets(string eventName, int numTickets)
        {
            foreach (var e in events)
            {
                if (e.EventName == eventName)
                {
                    if (e.AvailableSeats >= numTickets)
                    {
                        e.AvailableSeats -= numTickets;
                        Console.WriteLine($"Booked {numTickets} tickets for {eventName}.\n");
                    }
                    else
                    {
                        Console.WriteLine("Not enough available seats.\n");
                    }
                    return;
                }
            }
            Console.WriteLine("Event not found.\n");
        }

        public override void CancelTickets(string eventName, int numTickets)
        {
            foreach (var e in events)
            {
                if (e.EventName == eventName)
                {
                    if (numTickets <= (e.TotalSeats - e.AvailableSeats))
                    {
                        e.AvailableSeats += numTickets;
                        Console.WriteLine($"Cancelled {numTickets} tickets for {eventName}.\n");
                    }
                    else
                    {
                        Console.WriteLine("You cannot cancel more tickets than booked.\n");
                    }
                    return;
                }
            }
            Console.WriteLine("Event not found.\n");
        }

        public override int GetAvailableSeats(string eventName)
        {
            foreach (var e in events)
            {
                if (e.EventName == eventName)
                {
                    return e.AvailableSeats;
                }
            }
            Console.WriteLine("Event not found.\n");
            return -1;
        }

        public override void DisplayAllEvents()
        {
            Console.WriteLine("\n--- Event List ---");
            foreach (var e in events)
            {
                e.DisplayDetails();
            }
            Console.WriteLine();
        }
    }

    // Main Program with Command-based UI
    class Program
    {
        static void Main(string[] args)
        {
            BookingSystem system = new TicketBookingSystem();

            while (true)
            {
                Console.WriteLine("Commands: create_event | book_tickets | cancel_tickets | get_available_seats | view_events | exit");
                Console.Write("Enter command: ");
                string command = Console.ReadLine();

                if (command == "create_event")
                {
                    Console.Write("Enter Event Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Total Seats: ");
                    int seats = int.Parse(Console.ReadLine());
                    Console.Write("Enter Ticket Price: ");
                    decimal price = decimal.Parse(Console.ReadLine());
                    system.CreateEvent(name, seats, price);
                }
                else if (command == "book_tickets")
                {
                    Console.Write("Enter Event Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Number of Tickets: ");
                    int num = int.Parse(Console.ReadLine());
                    system.BookTickets(name, num);
                }
                else if (command == "cancel_tickets")
                {
                    Console.Write("Enter Event Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Number of Tickets to Cancel: ");
                    int num = int.Parse(Console.ReadLine());
                    system.CancelTickets(name, num);
                }
                else if (command == "get_available_seats")
                {
                    Console.Write("Enter Event Name: ");
                    string name = Console.ReadLine();
                    int available = system.GetAvailableSeats(name);
                    if (available >= 0)
                        Console.WriteLine($"Available Seats: {available}\n");
                }
                else if (command == "view_events")
                {
                    system.DisplayAllEvents();
                }
                else if (command == "exit")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid command.\n");
                }
            }
        }
    }
}




