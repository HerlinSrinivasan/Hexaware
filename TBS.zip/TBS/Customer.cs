﻿//TASK 4

//using System;


//namespace TBS
//{
//    public class Customer
//    {
//        private string customer_name;
//        private string email;
//        private string phone_number;

//        //default constructor
//        public Customer()
//        {
//            customer_name = "";
//            email = "";
//            phone_number = "";

//        }

//        //overload constructor
//        public Customer(string customer_name, string email, string phone_number)
//        {
//            this.customer_name = customer_name;
//            this.email = email;
//            this.phone_number = phone_number;
//        }

//        //getter and setter method

//        public void SetCustomerName(string customer_name)
//        {
//            this.customer_name = customer_name;
//        }
//        public string GetCustomerName()
//        {
//            return customer_name;
//        }

//        public void SetEmail(string email)
//        {
//            this.email = email;
//        }
//        public string GetEmail()
//        {
//            return email;
//        }

//        public void SetPhoneNumber(string phone_number)
//        {
//            this.phone_number = phone_number;
//        }
//        public string GetPhoneNumber()
//        {
//            return phone_number;
//        }

//        //display cystomer details
//        public void DisplayCustomerDetails()
//        {
//            Console.WriteLine("\n --------Customer Details-----");
//            Console.WriteLine("Name :" + customer_name);
//            Console.WriteLine("Email :" + email);
//            Console.WriteLine("Phone number :" + phone_number);
//            Console.WriteLine("\n ----------------");
//        }

//    }
//}
