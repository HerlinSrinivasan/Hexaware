﻿//// TASK 8: 
//using System;
//using System.Collections.Generic;

//namespace TBS
//{
//    internal class task8
//    { // TASK 1: Venue Class
//        public class Venue
//        {
//            public string VenueName { get; set; }
//            public string Address { get; set; }
//            public Venue() { VenueName = ""; Address = ""; }
//            public Venue(string venueName, string address)
//            { VenueName = venueName; Address = address; }
//            public void DisplayVenueDetails()
//            {
//                Console.WriteLine($"Venue: {VenueName}, Address: {Address}");
//            }
//        }

//        // TASK 2: EventType Enum
//        public enum EventType
//        {
//            Movie, Sports, Concert
//        }

//        // TASK 3: Abstract Event Class
//        public abstract class Event
//        {
//            public string EventName { get; set; }
//            public DateTime EventDate { get; set; }
//            public DateTime EventTime { get; set; }
//            public Venue Venue { get; set; }
//            public int TotalSeats { get; set; }
//            public int AvailableSeats { get; set; }
//            public decimal TicketPrice { get; set; }
//            public EventType EventType { get; set; }

//            public Event()
//            {
//                EventName = "";
//                EventDate = DateTime.Now;
//                EventTime = DateTime.Now;
//                Venue = new Venue();
//                TotalSeats = 100;
//                AvailableSeats = 100;
//                TicketPrice = 100;
//                EventType = EventType.Movie;
//            }
//            public Event(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice, EventType eventType)
//            {
//                EventName = eventName;
//                EventDate = eventDate;
//                EventTime = eventTime;
//                Venue = venue;
//                TotalSeats = totalSeats;
//                AvailableSeats = totalSeats;
//                TicketPrice = ticketPrice;
//                EventType = eventType;
//            }
//            public abstract void DisplayEventDetails();
//        }

//        // TASK 4: Event Subclasses
//        public class Movie : Event
//        {
//            public Movie(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Movie) { }

//            public override void DisplayEventDetails()
//            {
//                Console.WriteLine($"[Movie] {EventName} | Date: {EventDate.ToShortDateString()} | Time: {EventTime.ToShortTimeString()} | Venue: {Venue.VenueName} | Seats: {AvailableSeats}/{TotalSeats} | Price: {TicketPrice}");
//            }
//        }

//        public class Concert : Event
//        {
//            public Concert(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Concert) { }

//            public override void DisplayEventDetails()
//            {
//                Console.WriteLine($"[Concert] {EventName} | Date: {EventDate.ToShortDateString()} | Time: {EventTime.ToShortTimeString()} | Venue: {Venue.VenueName} | Seats: {AvailableSeats}/{TotalSeats} | Price: {TicketPrice}");
//            }
//        }

//        public class Sports : Event
//        {
//            public Sports(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Sports) { }

//            public override void DisplayEventDetails()
//            {
//                Console.WriteLine($"[Sports] {EventName} | Date: {EventDate.ToShortDateString()} | Time: {EventTime.ToShortTimeString()} | Venue: {Venue.VenueName} | Seats: {AvailableSeats}/{TotalSeats} | Price: {TicketPrice}");
//            }
//        }

//        // TASK 5: Customer Class
//        public class Customer
//        {
//            public string CustomerName { get; set; }
//            public string Email { get; set; }
//            public string PhoneNumber { get; set; }

//            public Customer() { CustomerName = ""; Email = ""; PhoneNumber = ""; }

//            public Customer(string customerName, string email, string phoneNumber)
//            {
//                CustomerName = customerName;
//                Email = email;
//                PhoneNumber = phoneNumber;
//            }

//            public void DisplayCustomerDetails()
//            {
//                Console.WriteLine($"Customer: {CustomerName}, Email: {Email}, Phone: {PhoneNumber}");
//            }
//        }

//        // TASK 6: Booking Class
//        public class Booking
//        {
//            private static int bookingCounter = 1;
//            public int BookingId { get; }
//            public Customer[] Customers { get; }
//            public Event BookedEvent { get; }
//            public int NumTickets { get; }
//            public decimal TotalCost { get; }
//            public DateTime BookingDate { get; }

//            public Booking(Customer[] customers, Event bookedEvent, int numTickets)
//            {
//                BookingId = bookingCounter++;
//                Customers = customers;
//                BookedEvent = bookedEvent;
//                NumTickets = numTickets;
//                TotalCost = numTickets * bookedEvent.TicketPrice;
//                BookingDate = DateTime.Now;
//            }

//            public void DisplayBookingDetails()
//            {
//                Console.WriteLine($"\n--- Booking ID: {BookingId} ---");
//                Console.WriteLine($"Event: {BookedEvent.EventName} ({BookedEvent.EventType}) | Tickets: {NumTickets} | Total Cost: {TotalCost} | Booking Date: {BookingDate}");
//                Console.WriteLine("--- Customer Details ---");
//                foreach (Customer c in Customers)
//                    c.DisplayCustomerDetails();
//                Console.WriteLine("------------------------\n");
//            }
//        }

//        // TASK 7: IEventServiceProvider Interface
//        public interface IEventServiceProvider
//        {
//            Event CreateEvent(string eventName, DateTime date, DateTime time, int totalSeats, decimal ticketPrice, EventType eventType, Venue venue);
//            Event[] GetEventDetails();
//            int GetAvailableNoOfTickets();
//        }

//        // TASK 8: IBookingSystemServiceProvider Interface
//        public interface IBookingSystemServiceProvider
//        {
//            decimal CalculateBookingCost(int numTickets, decimal ticketPrice);
//            void BookTickets(string eventName, int numTickets);
//            void CancelBooking(int bookingId);
//            void GetBookingDetails(int bookingId);
//        }

//        // TASK 9: EventServiceProviderImpl Class
//        public class EventServiceProviderImpl : IEventServiceProvider
//        {
//            protected List<Event> events = new List<Event>();

//            public virtual Event CreateEvent(string eventName, DateTime date, DateTime time, int totalSeats, decimal ticketPrice, EventType eventType, Venue venue)
//            {
//                Event newEvent;
//                if (eventType == EventType.Movie)
//                    newEvent = new Movie(eventName, date, time, venue, totalSeats, ticketPrice);
//                else if (eventType == EventType.Concert)
//                    newEvent = new Concert(eventName, date, time, venue, totalSeats, ticketPrice);
//                else
//                    newEvent = new Sports(eventName, date, time, venue, totalSeats, ticketPrice);

//                events.Add(newEvent);
//                Console.WriteLine("Event created successfully.");
//                return newEvent;
//            }

//            public virtual Event[] GetEventDetails()
//            {
//                return events.ToArray();
//            }

//            public virtual int GetAvailableNoOfTickets()
//            {
//                int totalAvailable = 0;
//                foreach (Event e in events)
//                    totalAvailable += e.AvailableSeats;
//                return totalAvailable;
//            }
//        }

//        // TASK 10: BookingSystemServiceProviderImpl Class
//        public class BookingSystemServiceProviderImpl : EventServiceProviderImpl, IBookingSystemServiceProvider
//        {
//            private List<Booking> bookings = new List<Booking>();

//            public decimal CalculateBookingCost(int numTickets, decimal price)
//            {
//                return numTickets * price;
//            }

//            public void BookTickets(string eventName, int numTickets)
//            {
//                Event selectedEvent = null;
//                foreach (Event e in events)
//                {
//                    if (e.EventName.ToLower() == eventName.ToLower())
//                    {
//                        selectedEvent = e;
//                        break;
//                    }
//                }

//                if (selectedEvent != null && selectedEvent.AvailableSeats >= numTickets)
//                {
//                    Customer[] customers = new Customer[numTickets];
//                    for (int i = 0; i < numTickets; i++)
//                    {
//                        Console.WriteLine($"Enter details for Customer {i + 1}:");
//                        Console.Write("Name: ");
//                        string name = Console.ReadLine();
//                        Console.Write("Email: ");
//                        string email = Console.ReadLine();
//                        Console.Write("Phone: ");
//                        string phone = Console.ReadLine();
//                        customers[i] = new Customer(name, email, phone);
//                    }

//                    selectedEvent.AvailableSeats -= numTickets;
//                    Booking booking = new Booking(customers, selectedEvent, numTickets);
//                    bookings.Add(booking);

//                    Console.WriteLine($"Booking successful. Booking ID: {booking.BookingId}, Total Cost: {booking.TotalCost}");
//                }
//                else
//                {
//                    Console.WriteLine("Event not found or insufficient seats.");
//                }
//            }
//            public void CancelBooking(int bookingId)
//            {
//                Booking bookingToRemove = null;

//                foreach (Booking b in bookings)
//                {
//                    if (b.BookingId == bookingId)
//                    {
//                        bookingToRemove = b;
//                        break;
//                    }
//                }

//                if (bookingToRemove != null)
//                {
//                    bookingToRemove.BookedEvent.AvailableSeats += bookingToRemove.NumTickets;
//                    bookings.Remove(bookingToRemove);
//                    Console.WriteLine("Booking cancelled successfully.");
//                }
//                else
//                {
//                    Console.WriteLine("Booking not found.");
//                }
//            }

//            public void GetBookingDetails(int bookingId)
//            {
//                Booking bookingToShow = null;

//                foreach (Booking b in bookings)
//                {
//                    if (b.BookingId == bookingId)
//                    {
//                        bookingToShow = b;
//                        break;
//                    }
//                }

//                if (bookingToShow != null)
//                {
//                    bookingToShow.DisplayBookingDetails();
//                }
//                else
//                {
//                    Console.WriteLine("Booking not found.");
//                }
//            }
           
//        }

//        // TASK 11: TicketBookingSystem Class (Main Method)
//        public class TicketBookingSystem
//        {
//            public static void Main(string[] args)
//            {
//                BookingSystemServiceProviderImpl system = new BookingSystemServiceProviderImpl();

//                while (true)
//                {
//                    Console.WriteLine("\n--- Ticket Booking System ---");
//                    Console.WriteLine("1. Create Event");
//                    Console.WriteLine("2. Book Tickets");
//                    Console.WriteLine("3. Cancel Booking");
//                    Console.WriteLine("4. Get Available Tickets");
//                    Console.WriteLine("5. Get Event Details");
//                    Console.WriteLine("6. Get Booking Details");
//                    Console.WriteLine("7. Exit");
//                    Console.Write("Enter choice: ");

//                    string choice = Console.ReadLine();

//                    switch (choice)
//                    {
//                        case "1":
//                            Console.Write("Event Name: ");
//                            string name = Console.ReadLine();
//                            Console.Write("Date (yyyy-MM-dd): ");
//                            DateTime date = DateTime.Parse(Console.ReadLine());
//                            Console.Write("Time (HH:mm): ");
//                            DateTime time = date.Date.Add(TimeSpan.Parse(Console.ReadLine()));
//                            Console.Write("Total Seats: ");
//                            int totalSeats = int.Parse(Console.ReadLine());
//                            Console.Write("Ticket Price: ");
//                            decimal price = decimal.Parse(Console.ReadLine());
//                            Console.Write("Event Type (Movie/Sports/Concert): ");
//                            EventType type = (EventType)Enum.Parse(typeof(EventType), Console.ReadLine(), true);
//                            Console.Write("Venue Name: ");
//                            string venueName = Console.ReadLine();
//                            Console.Write("Venue Address: ");
//                            string venueAddress = Console.ReadLine();
//                            Venue venue = new Venue(venueName, venueAddress);

//                            system.CreateEvent(name, date, time, totalSeats, price, type, venue);
//                            break;

//                        case "2":
//                            Console.Write("Event Name: ");
//                            string eventToBook = Console.ReadLine();
//                            Console.Write("Number of Tickets: ");
//                            int numTickets = int.Parse(Console.ReadLine());
//                            system.BookTickets(eventToBook, numTickets);
//                            break;

//                        case "3":
//                            Console.Write("Booking ID: ");
//                            int bookingId = int.Parse(Console.ReadLine());
//                            system.CancelBooking(bookingId);
//                            break;

//                        case "4":
//                            Console.WriteLine($"Total Available Tickets: {system.GetAvailableNoOfTickets()}");
//                            break;

//                        case "5":
//                            Event[] allEvents = system.GetEventDetails();
//                            foreach (Event e in allEvents)
//                                e.DisplayEventDetails();
//                            break;

//                        case "6":
//                            Console.Write("Booking ID: ");
//                            int bid = int.Parse(Console.ReadLine());
//                            system.GetBookingDetails(bid);
//                            break;

//                        case "7":
//                            return;

//                        default:
//                            Console.WriteLine("Invalid choice.");
//                            break;
//                    }
//                }
//            }
//        }
//    }

//}
