﻿
//========================================================================================================================
//TASK 7 : Has A Relation / Association 

//i have to create venue class,customer class and event class-- i have already done that

/* 3. Event sub classes: 
• Create three sub classes that inherit from Event abstract class and override abstract 
methods in concrete class should declare the variables as mentioned in above Task 2:*/

//event abstract class

//using System;
//using System.Collections.Generic;

//namespace TBS
//{
//    public enum EventType
//    {
//        Movie,
//        Sports,
//        Concert
//    }
//    public abstract class Events
//    {
//        private string eventName;
//        private DateTime eventDate;
//        private DateTime eventTime;
//        private Venue venue; // Has-A relationship
//        private int totalSeats;
//        private int availableSeats;
//        private decimal ticketPrice;
//        private EventType eventType;

//        // Default Constructor
//        public Events()
//        {
//            eventName = "";
//            eventDate = DateTime.Now;
//            eventTime = DateTime.Now;
//            venue = new Venue();
//            totalSeats = 0;
//            availableSeats = 0;
//            ticketPrice = 0;
//            eventType = EventType.Movie;
//        }

//        // Overloaded Constructor
//        public Events(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice, EventType eventType)
//        {
//            this.eventName = eventName;
//            this.eventDate = eventDate;
//            this.eventTime = eventTime;
//            this.venue = venue;
//            this.totalSeats = totalSeats;
//            this.ticketPrice = ticketPrice;
//            this.availableSeats = totalSeats;
//            this.eventType = eventType;
//        }

//        // Getters and Setters
//        public string EventName { get => eventName; set => eventName = value; }
//        public DateTime EventDate { get => eventDate; set => eventDate = value; }
//        public DateTime EventTime { get => eventTime; set => eventTime = value; }
//        public Venue Venue { get => venue; set => venue = value; }
//        public int TotalSeats { get => totalSeats; set => totalSeats = value; }
//        public int AvailableSeats { get => availableSeats; set => availableSeats = value; }
//        public decimal TicketPrice { get => ticketPrice; set => ticketPrice = value; }
//        public EventType EventType { get => eventType; set => eventType = value; }

//        // Revenue Calculation
//        public decimal CalculateTotalRevenue()
//        {
//            int sold = totalSeats - availableSeats;
//            return sold * ticketPrice;
//        }

//        public int GetTotalBookedTickets()
//        {
//            return totalSeats - availableSeats;
//        }
//        // Book tickets
//        public bool BookTickets(int numTickets)
//        {
//            if (numTickets <= availableSeats)
//            {
//                availableSeats -= numTickets;
//                return true;
//            }
//            return false;
//        }
//        // Cancel booking
//        public void CancelBooking(int numTickets)
//        {
//            if (availableSeats + numTickets <= totalSeats)
//            {
//                availableSeats += numTickets;
//            }
//        }
//        // Abstract method for subclasses to override
//        public abstract void DisplayEventDetails();
//    }

//        public class MovieEvent : Events
//        {
//            public MovieEvent(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Movie) { }

//            public override void DisplayEventDetails()
//            {
//                Console.WriteLine("\n--- Movie Event Details ---");
//                Console.WriteLine($"Name: {EventName}");
//                Console.WriteLine($"Date: {EventDate:d}");
//                Console.WriteLine($"Time: {EventTime}");
//                Console.WriteLine($"Venue: {Venue}");
//                Console.WriteLine($"Total Seats: {TotalSeats}");
//                Console.WriteLine($"Available Seats: {AvailableSeats}");
//                Console.WriteLine($"Ticket Price: ₹{TicketPrice}");
//            }
//        }

//            public class ConcertEvent : Events
//            {
//                public ConcertEvent(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                    : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Concert) { }

//                public override void DisplayEventDetails()
//                {
//                    Console.WriteLine("\n--- Concert Event Details ---");
//                    Console.WriteLine($"Name: {EventName}");
//                    Console.WriteLine($"Date: {EventDate:d}");
//                    Console.WriteLine($"Time: {EventTime}");
//                    Console.WriteLine($"Venue: {Venue}");
//                    Console.WriteLine($"Total Seats: {TotalSeats}");
//                    Console.WriteLine($"Available Seats: {AvailableSeats}");
//                    Console.WriteLine($"Ticket Price: ₹{TicketPrice}");
//                }
//            } 
//        public class SportEvent : Events
//        {
//            public SportEvent(string eventName, DateTime eventDate, DateTime eventTime, Venue venue, int totalSeats, decimal ticketPrice)
//                : base(eventName, eventDate, eventTime, venue, totalSeats, ticketPrice, EventType.Sports) { }

//            public override void DisplayEventDetails()
//            {
//                Console.WriteLine("\n--- Sports Event Details ---");
//                Console.WriteLine($"Name: {EventName}");
//                Console.WriteLine($"Date: {EventDate:d}");
//                Console.WriteLine($"Time: {EventTime}");
//            Console.WriteLine($"Venue: {Venue}");
//            Console.WriteLine($"Total Seats: {TotalSeats}");
//                Console.WriteLine($"Available Seats: {AvailableSeats}");
//                Console.WriteLine($"Ticket Price: ₹{TicketPrice}");
//            }
//        }
//}
//=====================================================
/* . Create a class Booking with the following attributes: 
• bookingId (should be incremented for each booking) 
• array of customer (reference to the customer who made the booking) 
• event (reference to the event booked) 
• num_tickets(no of tickets and array of customer must equal) 
• total_cost 
• booking_date (timestamp of when the booking was made) 
• Methods and Constuctors: 
o Implement default constructors and overload the constructor with Customer 
attributes, generate getter and setter methods. 
o display_booking_details(): Display customer details. */

//using System;
//using System.Collections.Generic;


//namespace TBS
//{
//    public class Bookings
//    {
//        private static int bookingCounter = 1000;

//        public int BookingId { get; }
//        public Customer[] Customers { get; set; } // here please uncomment the Customer class from Task 4(Event.cs)
//        public Event BookedEvent { get; set; } // here please uncomment the Event class from Task 4(Customer.cs)
//        public int NumTickets { get; set; }
//        public decimal TotalCost { get; set; }
//        public DateTime BookingDate { get; set; }

//        public Bookings()
//        {
//            BookingId = ++bookingCounter;
//            Customers = new Customer[0];
//            BookedEvent = null;
//            NumTickets = 0;
//            TotalCost = 0;
//            BookingDate = DateTime.Now;
//        }

//        public Bookings(Customer[] customers, Event bookedEvent, int numTickets, decimal totalCost)
//        {
//            BookingId = ++bookingCounter;
//            Customers = customers;
//            BookedEvent = bookedEvent;
//            NumTickets = numTickets;
//            TotalCost = totalCost;
//            BookingDate = DateTime.Now;
//        }

//        public void DisplayBookingDetails()
//        {
//            Console.WriteLine("\n--- Booking Details ---");
//            Console.WriteLine("Booking ID: " + BookingId);
//            Console.WriteLine("Event: " + BookedEvent.GetEventName() + " (" + BookedEvent.GetEventType() + ")");
//            Console.WriteLine("Booking Date: " + BookingDate);
//            Console.WriteLine("Number of Tickets: " + NumTickets);
//            Console.WriteLine("Total Cost: ₹" + TotalCost);


//            foreach (Customer customer in Customers)
//            {
//                customer.DisplayCustomerDetails();
//                Console.WriteLine();
//            }
//        }
//    }
//}


//namespace TBS
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            // Create sample events
//            List<Event> events = new List<Event>();
//            events.Add(new Event("Movie Night", DateTime.Now.Date, DateTime.Now, "PVR Cinema", 100, 200, EventType.Movie));
//            events.Add(new Event("Football Match", DateTime.Now.Date, DateTime.Now, "Stadium", 150, 500, EventType.Sports));
//            events.Add(new Event("Rock Concert", DateTime.Now.Date, DateTime.Now, "Concert Hall", 200, 1000, EventType.Concert));

//            Console.WriteLine("--- Available Events ---");

//            // Display events
//            for (int i = 0; i < events.Count; i++)
//            {
//                Console.WriteLine($"\nEvent {i + 1}:");
//                events[i].DisplayEventDetails();
//            }

//            // Let user pick event
//            Console.Write("\nEnter the Event Number to Book: ");
//            int eventChoice = Convert.ToInt32(Console.ReadLine());

//            if (eventChoice < 1 || eventChoice > events.Count)
//            {
//                Console.WriteLine("Invalid choice. Exiting...");
//                return;
//            }

//            Event selectedEvent = events[eventChoice - 1];

//            // Get number of tickets
//            Console.Write("Enter number of tickets to book: ");
//            int numTickets = Convert.ToInt32(Console.ReadLine());

//            if (numTickets > selectedEvent.GetAvailableSeats())
//            {
//                Console.WriteLine("Not enough tickets available.");
//                return;
//            }

//            // Get customer details for each ticket
//            Customer[] customers = new Customer[numTickets];

//            for (int i = 0; i < numTickets; i++)
//            {
//                Console.WriteLine($"\nEnter details for Customer {i + 1}:");
//                Console.Write("Name: ");
//                string name = Console.ReadLine();
//                Console.Write("Email: ");
//                string email = Console.ReadLine();
//                Console.Write("Phone: ");
//                string phone = Console.ReadLine();

//                customers[i] = new Customer(name, email, phone);
//            }

//            // Book the tickets
//            selectedEvent.BookTickets(numTickets);

//            // Create booking
//            decimal totalCost = numTickets * selectedEvent.GetTicketPrice();
//            Bookings booking = new Bookings(customers, selectedEvent, numTickets, totalCost);

//            // Display booking details
//            Console.WriteLine("\n--- Booking Successful ---");
//            booking.DisplayBookingDetails();
//        }
//    }
//}
//=========================================================
/* 6. BookingSystem Class to represent the Ticket booking system. Perform the following operation in 
main method. Note: - Use Event class object for the following operation. */

//using System;
//using System.Collections.Generic;

//namespace TBS
//{
//    public class BookingClass
//    {
//        private static int bookingCounter = 1;

//        // Attributes
//        private int bookingId;
//        private Customer[] customers;
//        private Event bookedEvent;
//        private int numTickets;
//        private decimal totalCost;
//        private DateTime bookingDate;

//        // Constructor
//        public BookingClass(Customer[] customers, Event bookedEvent, int numTickets)
//        {
//            this.bookingId = bookingCounter++;
//            this.customers = customers;
//            this.bookedEvent = bookedEvent;
//            this.numTickets = numTickets;
//            this.totalCost = numTickets * bookedEvent.GetTicketPrice();
//            this.bookingDate = DateTime.Now;
//        }

//        // Getter methods
//        public int GetBookingId() => bookingId;
//        public Event GetBookedEvent() => bookedEvent;
//        public int GetNumTickets() => numTickets;
//        public decimal GetTotalCost() => totalCost;
//        public DateTime GetBookingDate() => bookingDate;
//        public Customer[] GetCustomers() => customers;

//        // Display booking details
//        public void DisplayBookingDetails()
//        {
//            Console.WriteLine("\n--- Booking Details ---");
//            Console.WriteLine("Booking ID: " + bookingId);
//            Console.WriteLine("Event: " + bookedEvent.GetEventName());
//            Console.WriteLine("Event Type: " + bookedEvent.GetEventType());
//            Console.WriteLine("Number of Tickets: " + numTickets);
//            Console.WriteLine("Total Cost: " + totalCost);
//            Console.WriteLine("Booking Date: " + bookingDate);

//            Console.WriteLine("\n--- Customer Details ---");
//            foreach (Customer customer in customers)
//            {
//                customer.DisplayCustomerDetails();
//            }
//            Console.WriteLine("--------------------------\n");
//        }
//    }
//}
//namespace TBS
//{
//    public class BookingSystem
//    {
//        private List<Event> events = new List<Event>();
//        private List<BookingClass> bookings = new List<BookingClass>();

//        // Create Event
//        public Event CreateEvent(string event_name, DateTime date, DateTime time, int total_seats, decimal ticket_price, EventType event_type, string venue_name)
//        {
//            Event newEvent = new Event(event_name, date, time, venue_name, total_seats, ticket_price, event_type);
//            events.Add(newEvent);
//            Console.WriteLine("Event created successfully.\n");
//            return newEvent;
//        }

//        // Calculate Booking Cost
//        public decimal CalculateBookingCost(int num_tickets, decimal ticket_price)
//        {
//            return num_tickets * ticket_price;
//        }

// Book Tickets
// Book Tickets
//using System;
//using TicketBookingSystemApp;

//public void BookTickets(string eventname, int num_tickets)
//{
//    Event selectedEvent = events.Find(e => e.GetEventName() == eventname);

//    if (selectedEvent != null)
//    {
//        if (selectedEvent.GetAvailableSeats() >= num_tickets)
//        {
//            Customer[] customers = new Customer[num_tickets];
//            for (int i = 0; i < num_tickets; i++)
//            {
//                Console.WriteLine($"Enter details for Customer {i + 1}:");
//                Console.Write("Name: ");
//                string name = Console.ReadLine();
//                Console.Write("Email: ");
//                string email = Console.ReadLine();
//                Console.Write("Phone Number: ");
//                string phone = Console.ReadLine();

//                customers[i] = new Customer(name, email, phone);
//            }

//            selectedEvent.BookTickets(num_tickets);
//            BookingClass booking = new BookingClass(customers, selectedEvent, num_tickets);
//            bookings.Add(booking);
//            Console.WriteLine($"Booking successful. Booking ID: {booking.GetBookingId()} | Total Cost: {booking.GetTotalCost()}\n");
//        }
//        else
//        {
//            Console.WriteLine("Not enough available seats.\n");
//        }
//    }
//    else
//    {
//        Console.WriteLine("Event not found.\n");
//    }
//}

//// Cancel Booking
//public void CancelBooking(int booking_id)
//{
//    BookingClass booking = bookings.Find(b => b.GetBookingId() == booking_id);
//    if (booking != null)
//    {
//        booking.GetBookedEvent().CancelBooking(booking.GetNumTickets());
//        bookings.Remove(booking);
//        Console.WriteLine("Booking cancelled successfully.\n");
//    }
//    else
//    {
//        Console.WriteLine("Booking not found.\n");
//    }
//}

//// Get Available Tickets
//public void GetAvailableNoOfTickets(string eventname)
//{
//    Event selectedEvent = events.Find(e => e.GetEventName() == eventname);
//    if (selectedEvent != null)
//    {
//        Console.WriteLine($"Available Seats for {eventname}: {selectedEvent.GetAvailableSeats()}\n");
//    }
//    else
//    {
//        Console.WriteLine("Event not found.\n");
//    }
//}

//// Get Event Details
//public void GetEventDetails(string eventname)
//{
//    Event selectedEvent = events.Find(e => e.GetEventName() == eventname);
//    if (selectedEvent != null)
//    {
//        selectedEvent.DisplayEventDetails();
//    }
//    else
//    {
//        Console.WriteLine("Event not found.\n");
//    }
//}


//    }
//}

//// Cancel Booking
//public void CancelBooking(int booking_id)
//{
//    BookingClass bookingToRemove = null;

//    foreach (BookingClass b in bookings)
//    {
//        if (b.GetBookingId() == booking_id)
//        {
//            bookingToRemove = b;
//            break;
//        }
//    }

//    if (bookingToRemove != null)
//    {
//        bookingToRemove.GetBookedEvent().CancelBooking(bookingToRemove.GetNumTickets());
//        bookings.Remove(bookingToRemove);
//        Console.WriteLine("Booking cancelled successfully.\n");
//    }
//    else
//    {
//        Console.WriteLine("Booking not found.\n");
//    }
//}

//// Get Available Tickets
//public void GetAvailableNoOfTickets(string eventname)
//{
//    Event selectedEvent = null;

//    foreach (Event e in events)
//    {
//        if (e.GetEventName() == eventname)
//        {
//            selectedEvent = e;
//            break;
//        }
//    }

//    if (selectedEvent != null)
//    {
//        Console.WriteLine($"Available Seats for {eventname}: {selectedEvent.GetAvailableSeats()}\n");
//    }
//    else
//    {
//        Console.WriteLine("Event not found.\n");
//    }
//}

//public void GetEventDetails(string eventname)
//{
//    Event selectedEvent = null;

//    foreach (Event e in events)
//    {
//        if (e.GetEventName() == eventname)
//        {
//            selectedEvent = e;
//            break;
//        }
//    }

//    if (selectedEvent != null)
//    {
//        selectedEvent.DisplayEventDetails();
//    }
//    else
//    {
//        Console.WriteLine("Event not found.\n");
//    }
//}


//    }
//}
    


