﻿//// Task 10 - Collections Implementation 
//using System;
//using System.Collections.Generic;

//namespace TBS.Task10
//{
//    // 1. Venue Class 
//    public class Venue
//    {
//        public string VenueName { get; set; }
//        public string Address { get; set; }

//        public Venue(string venueName, string address)
//        {
//            VenueName = venueName;
//            Address = address;
//        }
//    }

//    // 2. EventType Enum
//    public enum EventType { Movie, Sports, Concert }

//    // 3. Event Class
//    public class Event : IComparable<Event>
//    {
//        public string EventName { get; set; }
//        public Venue Venue { get; set; }

//        public Event(string eventName, Venue venue)
//        {
//            EventName = eventName;
//            Venue = venue;
//        }

//        public int CompareTo(Event other)
//        {
//            int nameComparison = this.EventName.CompareTo(other.EventName);
//            return nameComparison == 0 ? this.Venue.VenueName.CompareTo(other.Venue.VenueName) : nameComparison;
//        }
//    }

//    // 4. Customer Class
//    public class Customer
//    {
//        public string Name { get; set; }
//        public Customer(string name) { Name = name; }

//        public override bool Equals(object obj)
//        {
//            return obj is Customer c && c.Name == this.Name;
//        }

//        public override int GetHashCode() => Name.GetHashCode();
//    }

//    // 5. Booking Class - Using Set
//    public class Booking
//    {
//        public HashSet<Customer> Customers { get; set; } = new HashSet<Customer>();
//        public Event BookedEvent { get; set; }

//        public Booking(Event bookedEvent)
//        {
//            BookedEvent = bookedEvent;
//        }
//    }

//    // 6. BookingSystem with Set and Comparator
//    public class BookingSystem
//    {
//        private SortedSet<Event> events = new SortedSet<Event>();

//        public void AddEvent(Event e)
//        {
//            if (events.Add(e))
//                Console.WriteLine("Event added.");
//            else
//                Console.WriteLine("Event already exists.");
//        }

//        public void ShowEvents()
//        {
//            foreach (var e in events)
//                Console.WriteLine($"{e.EventName} at {e.Venue.VenueName}");
//        }
//    }

//    // 7. Main Method
//    public class Task10Main
//    {
//        public static void Main()
//        {
//            BookingSystem system = new BookingSystem();

//            Venue v1 = new Venue("Stadium", "City Center");
//            Venue v2 = new Venue("Arena", "Downtown");

//            system.AddEvent(new Event("Football", v1));
//            system.AddEvent(new Event("Concert", v2));
//            system.AddEvent(new Event("Football", v1)); // Duplicate, won't add
//            system.AddEvent(new Event("Concert", v2)); //will display event already exists
//            system.ShowEvents();
//        }
//    }
//}


