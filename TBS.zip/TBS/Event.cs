﻿//TASK 4

using System;


namespace TBS
{
    public enum EventType
    {
        Movie,
        Sports,
        Concert
    }
    //Event Class
    public class Event
    {
        private string event_name;
        private DateTime event_date;
        private DateTime event_time;
        private string venue_name;
        private int total_seats;
        private int available_seats;
        private decimal ticket_price;
        private EventType event_type;


        // Default constructor
        public Event()
        {
            event_name = "";
            event_date = DateTime.Now;
            event_time = DateTime.Now;
            venue_name = "";
            total_seats = 100;
            available_seats = 100; // Initially all seats are available
            ticket_price = 1000; // Default ticket price
            event_type = EventType.Movie;
        }

        // Overloaded constructor
        public Event(string event_name, DateTime event_date, DateTime event_time, string venue_name, int total_seats, decimal ticket_price, EventType event_type)
        {
            this.event_name = event_name;
            this.event_date = event_date;
            this.event_time = event_time;
            this.venue_name = venue_name;
            this.total_seats = total_seats;
            this.ticket_price = ticket_price;
            this.event_type = event_type;
            this.available_seats = total_seats;
        }

        //GETTER AND SETTER METHODS
        public void SetEventName(string name)
        {
            this.event_name = name;
        }
        public string GetEventName()
        {
            return event_name;
        }
        public void SetEventDate(DateTime date)
        {
            this.event_date = date;
        }
        public DateTime GetEventDate()
        {
            return event_date;
        }
        public void SetEventTime(DateTime time)
        {
            this.event_time = time;
        }
        public DateTime GetEventTime()
        {
            return event_time;
        }
        public void SetVenueName(string venue)
        {
            this.venue_name = venue;
        }
        public string GetVenueName()
        {
            return venue_name;
        }
        public void SetTotalSeats(int seats)
        {
            this.total_seats = seats;
        }
        public int GetTotalSeats()
        {
            return total_seats;
        }
        public void SetAvailableSeats(int seats)
        {
            this.available_seats = seats;
        }
        public int GetAvailableSeats()
        {
            return available_seats;
        }
        public void SetTicketPrice(decimal price)
        {
            this.ticket_price = price;
        }
        public decimal GetTicketPrice()
        {
            return ticket_price;
        }
        public void SetEventType(EventType type)
        {
            this.event_type = type;
        }
        public string GetEventType()
        {
            return event_type.ToString();
        }

        //calculate the total revenue generated

        //method to calculate total revenue generated from ticket sales
        public decimal CalculateTotalRevenue()
        {
            int sold = total_seats - available_seats;
            return sold * ticket_price;
        }

        //method to get total booked tickets

        public int GetTotalBookedTickets()
        {
            return total_seats - available_seats;
        }

        /* Book a specified number of tickets for an event. Initially 
        available seats are equal to the total seats when tickets are booked available seats
    number should be reduced.*/
        public bool BookTickets(int num_tickets)
        {
            if (num_tickets <= available_seats)
            {
                available_seats -= num_tickets;
                Console.WriteLine(num_tickets + " " + "tickets booked successfully");
                return true;
            }
            else
            {
                Console.WriteLine("Not enough tickets available");
                return false;
            }
        }

        // Cancel the booking and update the available seats. 

        public void CancelBooking(int num_tickets)
        {
            if ((available_seats) + num_tickets <= total_seats)
            {
                available_seats += num_tickets;
                Console.WriteLine(num_tickets + "tickets cancelled successfully");
            }

        }

        // Display event details, including event name, date time seat  availability.
        public void DisplayEventDetails()
        {
            Console.WriteLine("\n ---------Event Details-----");
            Console.WriteLine("Name :" + event_name);
            Console.WriteLine("Date :" + event_date);
            Console.WriteLine("Time :" + event_time);
            Console.WriteLine("Venue :" + venue_name);
            Console.WriteLine("Total seats :" + total_seats);
            Console.WriteLine("Available seats :" + available_seats);
            Console.WriteLine("Ticket price :" + ticket_price);
            Console.WriteLine("Event type :" + event_type);
            Console.WriteLine("\n ----------------");
        }


    }
}
