﻿//using System;
//using System.Collections.Generic;

//namespace Task9
//{
//    // 1. Custom Exceptions
//    public class EventNotFoundException : Exception
//    {
//        public EventNotFoundException(string message) : base(message) { }
//    }

//    public class InvalidBookingIDException : Exception
//    {
//        public InvalidBookingIDException(string message) : base(message) { }
//    }
//    //creating class for Task 9 testing
//    // 2. Venue Class
//    public class Venue
//    {
//        public string VenueName;
//        public string Address;

//        public Venue(string name, string address)
//        {
//            VenueName = name;
//            Address = address;
//        }
//    }

//    // 3. Event Class
//    public class Event
//    {
//        public string EventName;
//        public int TotalSeats;
//        public int AvailableSeats;
//        public decimal TicketPrice;
//        public Venue Venue;

//        public Event(string name, int seats, decimal price, Venue venue)
//        {
//            EventName = name;
//            TotalSeats = seats;
//            AvailableSeats = seats;
//            TicketPrice = price;
//            Venue = venue;
//        }
//    }

//    // 4. Booking Class
//    public class Booking
//    {
//        private static int bookingCounter = 1;
//        public int BookingId;
//        public Event BookedEvent;
//        public int NumTickets;
//        public decimal TotalCost;

//        public Booking(Event bookedEvent, int numTickets)
//        {
//            BookingId = bookingCounter++;
//            BookedEvent = bookedEvent;
//            NumTickets = numTickets;
//            TotalCost = numTickets * bookedEvent.TicketPrice;
//        }
//    }

//    // 5. BookingSystem Class with Exception Handling
//    public class BookingSystem
//    {
//        public List<Event> events = new List<Event>();
//        public List<Booking> bookings = new List<Booking>();

//        public void AddEvent(Event e)
//        {
//            events.Add(e);
//        }

//        public void BookTickets(string eventName, int numTickets)
//        {
//            Event selectedEvent = null;

//            foreach (Event e in events)
//            {
//                if (e.EventName == eventName)
//                {
//                    selectedEvent = e;
//                    break;
//                }
//            }

//            if (selectedEvent == null)
//            {
//                throw new EventNotFoundException("Event not found.");
//            }

//            if (selectedEvent.AvailableSeats >= numTickets)
//            {
//                selectedEvent.AvailableSeats -= numTickets;
//                Booking booking = new Booking(selectedEvent, numTickets);
//                bookings.Add(booking);
//                Console.WriteLine($"Booking successful. Booking ID: {booking.BookingId}, Total Cost: {booking.TotalCost}");
//            }
//            else
//            {
//                Console.WriteLine("Not enough seats available.");
//            }
//        }

//        public void CancelBooking(int bookingId)
//        {
//            bool found = false;

//            for (int i = 0; i < bookings.Count; i++)
//            {
//                if (bookings[i].BookingId == bookingId)
//                {
//                    bookings[i].BookedEvent.AvailableSeats += bookings[i].NumTickets;
//                    bookings.RemoveAt(i);
//                    Console.WriteLine("Booking cancelled successfully.");
//                    found = true;
//                    break;
//                }
//            }

//            if (!found)
//            {
//                throw new InvalidBookingIDException("Invalid Booking ID.");
//            }
//        }

//        public void ViewBooking(int bookingId)
//        {
//            bool found = false;

//            foreach (Booking b in bookings)
//            {
//                if (b.BookingId == bookingId)
//                {
//                    Console.WriteLine($"Booking ID: {b.BookingId}, Event: {b.BookedEvent.EventName}, Tickets: {b.NumTickets}, Total Cost: {b.TotalCost}");
//                    found = true;
//                    break;
//                }
//            }

//            if (!found)
//            {
//                throw new InvalidBookingIDException("Invalid Booking ID.");
//            }
//        }
//    }

//    // 6. Main Method with try-catch
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            BookingSystem system = new BookingSystem();

//            // Pre-added Event
//            system.AddEvent(new Event("Music Concert", 50, 500, new Venue("City Hall", "Downtown")));

//            try
//            {
//                Console.Write("Enter Event Name to Book: ");
//                string name = Console.ReadLine();

//                Console.Write("Enter Number of Tickets: ");
//                int tickets = int.Parse(Console.ReadLine());

//                system.BookTickets(name, tickets);
//            }
//            catch (EventNotFoundException ex)
//            {
//                Console.WriteLine("Error: " + ex.Message);
//            }
//            catch (NullReferenceException)
//            {
//                Console.WriteLine("Error: Something was missing. Please check your input.");
//            }

//            try
//            {
//                Console.Write("Enter Booking ID to Cancel: ");
//                int id = int.Parse(Console.ReadLine());

//                system.CancelBooking(id);
//            }
//            catch (InvalidBookingIDException ex)
//            {
//                Console.WriteLine("Error: " + ex.Message);
//            }
//            catch (NullReferenceException)
//            {
//                Console.WriteLine("Error: Something was missing. Please check your input.");
//            }
//        }
//    }
//}