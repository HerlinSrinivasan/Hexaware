﻿////TASK 5
//using System;


//namespace TBS
//{
//    public class Sport : Event
//    {

//        public string sportName;
//        public string teamsName;


//        //default constructor

//        public Sport() : base()
//        {
//            sportName = "";
//            teamsName = "";
//        }

//        //overload constructor

//        public Sport(string event_name, DateTime event_date, DateTime event_time, string venue_name, int total_seats, decimal ticket_price, EventType event_type, string genre, string sportName, string teamsName) : base(event_name, event_date, event_time, venue_name, total_seats, ticket_price, event_type)
//        {
//            this.sportName = sportName;
//            this.teamsName = teamsName;
//        }

//        public new void DisplayEventDetails()
//        {
//            base.DisplayEventDetails();

//            Console.WriteLine("Sport: " + sportName);
//            Console.WriteLine("Team Names: " + teamsName);
//        }

//    }
//}