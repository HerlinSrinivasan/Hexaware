﻿//using System;
//using System.Data.SqlClient;
//using System.Threading.Tasks;
//using System.Xml.Linq;



//namespace TicketBookingSystemApp
//{
//    // 1. Venue Class
//    public class Venue
//    {
//        public string VenueName { get; set; }
//        public string Address { get; set; }
//        public Venue() { VenueName = ""; Address = ""; }
//        public Venue(string venueName, string address)
//        { VenueName = venueName; Address = address; }
//    }

//    // 2. EventType Enum
//    public enum EventType
//    {
//        Movie, Sports, Concert
//    }

//    // 3. Abstract Event Class
//    public abstract class Event
//    {
//        public string EventName { get; set; }
//        public DateTime EventDate { get; set; }
//        public DateTime EventTime { get; set; }
//        public Venue Venue { get; set; }
//        public int TotalSeats { get; set; }
//        public int AvailableSeats { get; set; }
//        public decimal TicketPrice { get; set; }
//        public EventType EventType { get; set; }
//    }

//    // 4. Event Subclasses
//    public class Movie : Event { }
//    public class Concert : Event { }
//    public class Sports : Event { }

//    // 5. Customer Class
//    public class Customer
//    {
//        public string CustomerName { get; set; }
//        public string Email { get; set; }
//        public string PhoneNumber { get; set; }
//    }

//    // 6. Booking Class
//    public class Booking
//    {
//        public int BookingId { get; set; }
//        public string EventName { get; set; }
//        public string CustomerName { get; set; }
//        public int NumTickets { get; set; }
//        public decimal TotalCost { get; set; }
//        public DateTime BookingDate { get; set; }
//    }

//    // 7. IBookingSystemRepository Interface
//    public interface IBookingSystemRepository
//    {
//        void CreateEvent(string eventName, string date, string time, int totalSeats, decimal price, string eventType, string venueName, string venueAddress);
//        void GetEventDetails();
//        void BookTickets(string eventName, int numTickets, string customerName);
//        void CancelBooking(int bookingId);
//        void GetBookingDetails(int bookingId);
//    }

//    // 8. DBUtil - Utility class for DB connection
//    public class DBUtil
//    {
//        public static SqlConnection GetDBConn()
//        {
//            SqlConnection con = new SqlConnection("Server=DESKTOP-BCL1U6L;Initial Catalog=TicketBookingSystem;Integrated Security=True;TrustServerCertificate=True;");
//            con.Open();
//            return con;
//        }
//    }

//    // 9. BookingSystemRepositoryImpl - Implements database operations
//    public class BookingSystemRepositoryImpl : IBookingSystemRepository
//    {
//        // 9.1 Create Event
//        public void CreateEvent(string eventName, string date, string time, int totalSeats, decimal price, string eventType, string venueName, string venueAddress)
//        {
//            //getting venue_id
//            using (SqlConnection con = DBUtil.GetDBConn())
//            {
//                string venueQuery = $"SELECT venue_id from Venue WHERE venue_name = '{venueName}'";
//                SqlCommand cmd = new SqlCommand(venueQuery, con);
//                cmd.ExecuteNonQuery();
//                object venueResult = cmd.ExecuteScalar(); // it returns the 1st column of thr first row
//                if (venueResult != null)
//                {
//                    string query = $"INSERT INTO Event (event_name, event_date, event_time, total_seats, available_seats, ticket_price, event_type, venue_name, venue_address) " +
//                                   $"VALUES ('{eventName}', '{date}', '{time}', {totalSeats}, {totalSeats}, {price}, '{eventType}', '{venueName}', '{venueAddress}')";
//                    SqlCommand cmd1 = new SqlCommand(query, con);
//                    cmd1.ExecuteNonQuery();
//                    Console.WriteLine("Event created successfully.");
//                }
//                else
//                {
//                    Console.WriteLine("Venue not found.Please check the venue name");
//                }
//            }
//        }

//        // 9.2 Get Event Details
//        public void GetEventDetails()
//        {
//            using (SqlConnection con = DBUtil.GetDBConn())
//            {
//                string query = "SELECT * FROM Event";
//                SqlCommand cmd = new SqlCommand(query, con);
//                SqlDataReader reader = cmd.ExecuteReader();
//                Console.WriteLine("\n--- Event Details ---");
//                while (reader.Read())
//                {
//                    Console.WriteLine($"{reader["event_name"]} | Date: {reader["event_date"]} | Time: {reader["event_time"]} | Seats: {reader["available_seats"]}/{reader["total_seats"]} | Price: {reader["ticket_price"]}");
//                }
//                reader.Close();
//            }
//        }

//        // 9.3 Book Tickets
//        public void BookTickets(string eventName, int numTickets, string customerName)
//        {
//            using (SqlConnection con = DBUtil.GetDBConn())
//            {
//                string selectQuery = $"SELECT available_seats, ticket_price FROM Event WHERE event_name = '{eventName}'";
//                SqlCommand cmd = new SqlCommand(selectQuery, con);
//                SqlDataReader reader = cmd.ExecuteReader();

//                if (reader.Read())
//                {
//                    int available = (int)reader["available_seats"];
//                    decimal price = (decimal)reader["ticket_price"];
//                    reader.Close();

//                    if (available >= numTickets)
//                    {
//                        // Step 1: Get Max Booking ID
//                        string getMaxIdQuery = "SELECT ISNULL(MAX(booking_id), 0) + 1 FROM Booking";
//                        SqlCommand cmdMax = new SqlCommand(getMaxIdQuery, con);
//                        int newBookingId = (int)cmdMax.ExecuteScalar();

//                        // Step 2: Insert Booking with new ID
//                        string insertBooking = $"INSERT INTO Booking (booking_id,  num_tickets, total_cost, booking_date) " +
//                                               $"VALUES ({newBookingId}, {numTickets}, {numTickets * price}, GETDATE())";
//                        SqlCommand cmd2 = new SqlCommand(insertBooking, con);
//                        cmd2.ExecuteNonQuery();

//                        // Step 3: Update Seats
//                        string updateSeats = $"UPDATE Event SET available_seats = available_seats - {numTickets} WHERE event_name = '{eventName}'";
//                        SqlCommand cmd3 = new SqlCommand(updateSeats, con);
//                        cmd3.ExecuteNonQuery();

//                        Console.WriteLine($"Booking successful. Booking ID: {newBookingId}");
//                    }
//                    else
//                    {
//                        Console.WriteLine("Insufficient seats available.");
//                    }
//                }
//                else
//                {
//                    Console.WriteLine("Event not found.");
//                }
//            }
//        }

//        // 9.4 Cancel Booking
//        public void CancelBooking(int bookingId)
//        {
//            using (SqlConnection con = DBUtil.GetDBConn())
//            {
//                // Step 1: Get event_id and num_tickets from Booking table
//                string selectQuery = $"SELECT event_id, num_tickets FROM Booking WHERE booking_id = {bookingId}";
//                SqlCommand cmd = new SqlCommand(selectQuery, con);
//                SqlDataReader reader = cmd.ExecuteReader();

//                if (reader.Read())
//                {
//                    int eventId = (int)reader["event_id"];
//                    int numTickets = (int)reader["num_tickets"];
//                    reader.Close();

//                    // Step 2: Delete dependent Customer records first
//                    string deleteCustomers = $"DELETE FROM Customer WHERE booking_id = {bookingId}";
//                    SqlCommand cmdCustomers = new SqlCommand(deleteCustomers, con);
//                    cmdCustomers.ExecuteNonQuery();

//                    // Step 3: Delete the booking
//                    string deleteBooking = $"DELETE FROM Booking WHERE booking_id = {bookingId}";
//                    SqlCommand cmdBooking = new SqlCommand(deleteBooking, con);
//                    cmdBooking.ExecuteNonQuery();

//                    // Step 4: Update available seats
//                    string updateSeats = $"UPDATE Event SET available_seats = available_seats + {numTickets} WHERE event_id = {eventId}";
//                    SqlCommand cmdSeats = new SqlCommand(updateSeats, con);
//                    cmdSeats.ExecuteNonQuery();

//                    Console.WriteLine("Booking cancelled successfully.");
//                }
//                else
//                {
//                    Console.WriteLine("Booking not found.");
//                }
//            }
//        }

//        // 9.5 Get Booking Details
//        public void GetBookingDetails(int bookingId)
//        {
//            using (SqlConnection con = DBUtil.GetDBConn())
//            {
//                string query = $"SELECT * FROM Booking WHERE booking_id = {bookingId}";
//                SqlCommand cmd = new SqlCommand(query, con);
//                SqlDataReader reader = cmd.ExecuteReader();

//                if (reader.Read())
//                {
//                    Console.WriteLine($"\n--- Booking Details ---");
//                    Console.WriteLine($"Booking ID: {reader["booking_id"]}");
   
//                    Console.WriteLine($"Tickets: {reader["num_tickets"]}");
//                    Console.WriteLine($"Total Cost: {reader["total_cost"]}");
//                    Console.WriteLine($"Booking Date: {reader["booking_date"]}");
//                }
//                else
//                {
//                    Console.WriteLine("Booking not found.");
//                }
//                reader.Close();
//            }
//        }
//    }

//    // 10. Main Class - User Interface
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            BookingSystemRepositoryImpl repo = new BookingSystemRepositoryImpl();

//            while (true)
//            {
//                Console.WriteLine("\n--- Ticket Booking System ---");
//                Console.WriteLine("1. Create Event");
//                Console.WriteLine("2. View Events");
//                Console.WriteLine("3. Book Tickets");
//                Console.WriteLine("4. Cancel Booking");
//                Console.WriteLine("5. Get Booking Details");
//                Console.WriteLine("6. Exit");
//                Console.Write("Enter choice: ");
//                string choice = Console.ReadLine();

//                switch (choice)
//                {
//                    case "1":
//                        Console.Write("Event Name: ");
//                        string ename = Console.ReadLine();
//                        Console.Write("Date (yyyy-MM-dd): ");
//                        string edate = Console.ReadLine();
//                        Console.Write("Time (HH:mm): ");
//                        string etime = Console.ReadLine();
//                        Console.Write("Total Seats: ");
//                        int seats = int.Parse(Console.ReadLine());
//                        Console.Write("Ticket Price: ");
//                        decimal price = decimal.Parse(Console.ReadLine());
//                        Console.Write("Event Type (Movie/Sports/Concert): ");
//                        string etype = Console.ReadLine();
//                        Console.Write("Venue Name: ");
//                        string vname = Console.ReadLine();
//                        Console.Write("Venue Address: ");
//                        string vaddr = Console.ReadLine();
                       
//                            repo.CreateEvent(ename, edate, etime, seats, price, etype, vname, vaddr);
//                        break;

//                    case "2":
//                        repo.GetEventDetails();
//                        break;

//                    case "3":
//                        Console.Write("Event Name: ");
//                        string bEvent = Console.ReadLine();
//                        Console.Write("No. of Tickets: ");
//                        int numT = int.Parse(Console.ReadLine());
//                        Console.Write("Customer Name: ");
//                        string cname = Console.ReadLine();

//                        repo.BookTickets(bEvent, numT, cname);
//                        break;

//                    case "4":
//                        Console.Write("Booking ID: ");
//                        int bid = int.Parse(Console.ReadLine());
//                        repo.CancelBooking(bid);
//                        break;

//                    case "5":
//                        Console.Write("Booking ID: ");
//                        int bdet = int.Parse(Console.ReadLine());
//                        repo.GetBookingDetails(bdet);
//                        break;

//                    case "6":
//                        return;

//                    default:
//                        Console.WriteLine("Invalid choice.");
//                        break;
//                }
//            }
//        }
//    }
//}




