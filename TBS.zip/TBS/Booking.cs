﻿////TASK 4

//using System;


//namespace TBS
//{
//    public class Booking
//    {
//        //attributes
//        private Event bookedEvent;
//        private decimal totalCost;


//        //constructor
//        public Booking(Event ev)
//        {
//            this.bookedEvent = ev;
//            this.totalCost = 0;
//        }
//        /* calculate_booking_cost(num_tickets): Calculate and set the total cost of the 
//booking. */
//        public void CalculateBookingCost(int num_tickets)
//        {
//            totalCost = num_tickets * bookedEvent.GetTicketPrice();
//            Console.WriteLine("Total Booking Cost : " + totalCost);
//        }
//        /* book_tickets(num_tickets): Book a specified number of tickets for an event.*/
//        public void BookTickets(int num_tickets)
//        {
//            if (num_tickets <= bookedEvent.GetAvailableSeats())
//            {
//                bookedEvent.BookTickets(num_tickets);
//                CalculateBookingCost(num_tickets);
//                Console.WriteLine("Tickets Booked Successfully!");
//            }
//            else
//            {
//                Console.WriteLine("Not enough tickets available.");
//            }
//        }
//        /*cancel_booking(num_tickets): Cancel the booking and update the available seats.*/
//        public void CancelBooking(int num_tickets)
//        {
//            bookedEvent.CancelBooking(num_tickets);
//            Console.WriteLine(num_tickets + " ticket cancelled successfully.");
//        }
//        /* getAvailableNoOfTickets(): return the total available tickets*/
//        public int GetAvailableNoOfTickets()
//        {
//            return bookedEvent.GetAvailableSeats();
//        }
//        /* getEventDetails(): return event details from the event class*/
//        public void GetEventDetails()
//        {
//            bookedEvent.DisplayEventDetails();
//        }

//    }

//}
